package com.sist;

public class SalGradeDTO {

}
