package com.sist;

public class EmpDAO {

}
