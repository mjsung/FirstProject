package com.sist;

public class DeptDTO {

}
