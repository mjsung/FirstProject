package com.sist.dao;

public interface EmpMapper {

}
