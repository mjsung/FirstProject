package com.sist.news;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.util.*;
public class MainClass {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
        JAXBContext jc=JAXBContext.newInstance(Member.class);
        Unmarshaller um=jc.createUnmarshaller();
        Member mem=(Member)um.unmarshal(new File("C:\\springDev\\springStudy\\NewsFindProject\\src\\main\\java\\com\\sist\\news\\member.xml"));
        List<Mlist> list=mem.getMlist();
        for(Mlist m:list)
        {
        	System.out.println(m.getName()+" "
        			+m.getSex()+" "
        			+m.getAddr()+" "
        			+m.getTel());
        }
	}

}
