package com.sist.image;

import org.rosuda.REngine.Rserve.RConnection;
// 7e0f8b764675ac488e999d33f73f4aa9
public class CreateMainImage {
   public void logImage()
   {
	   try
	   {
		   String path="C:/webDev/webStudy4/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/JSPIncludeProject/main/log.csv";
	       RConnection rc=new RConnection();
	       rc.voidEval("data<-read.csv(\"C:/webDev/webStudy4/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/JSPIncludeProject/main/log.csv\",header=T,sep=\",\")");
	       rc.voidEval("png(\"C:/webDev/webStudy4/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/JSPIncludeProject/main/log.png\",width=500,height=350)");
	       rc.voidEval("barplot(data$count,names=data$name,col=rainbow(14),main=\"Login Status\")");
	       rc.voidEval("dev.off()");
	       rc.close();
	   }catch(Exception ex)
	   {
		   System.out.println(ex.getMessage());
	   }
   }
}
