package com.sist.test;

public class DeptDTO {

}
