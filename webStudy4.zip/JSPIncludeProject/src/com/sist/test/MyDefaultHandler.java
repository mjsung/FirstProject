package com.sist.test;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/*
 *   SAX ==> Simple API for XML 
 *   <?xml version="1.0"> startDocument
 *   <root> : table��  startElement
 *    <name id="">aaa</name>
 *    startElement characters endElement
 *    <sex>aaa</sex>
 *    startElement characters endElement
 *    <age>aa</age>
 *    startElement characters endElement
 *   </root> endElement
 *     endDocument
 */
import java.util.*;

public class MyDefaultHandler extends DefaultHandler{
    Map map=new HashMap();
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		try
		{
			if(qName.equals("Resource"))
			{
				String driver=attributes.getValue("driverClassName");
				String url=attributes.getValue("url");
				String username=attributes.getValue("username");
				String password=attributes.getValue("password");
				String maxActive=attributes.getValue("maxActive");
				String maxIdle=attributes.getValue("maxIdle");
				String maxWait=attributes.getValue("maxWait");
				String type=attributes.getValue("type");
				String name=attributes.getValue("name");
				Class clsName=Class.forName(type);
				MyDataSource ms=(MyDataSource)clsName.newInstance();
				ms.setDriverClassName(driver);
				ms.setMaxActive(Integer.parseInt(maxActive));
				ms.setPassword(password);
				ms.setUrl(url);
				ms.setUsername(username);
				ms.setMaxWait(Integer.parseInt(maxWait));
				ms.setMaxIdle(Integer.parseInt(maxIdle));
				ms.driverLoading();
				map.put(name, ms);
			}
		}catch(Exception ex){}
	}
   
}





