package com.jsp.change;

public class JspChange {
    private static String[] jsp={
    	"../main/default.jsp",
    	"../member/join.jsp",
    	"../board/list.jsp",
    	"../member/join_yes.jsp",
    	"../databoard/list.jsp",
    	"../databoard/insert.jsp",
    	"../databoard/content.jsp",
    	"../databoard/update.jsp",
    	"../movie/list.jsp",
    	"../movie/detail.jsp"
    };
    public static String jspChange(int no)
    {
    	return jsp[no];
    }
}
