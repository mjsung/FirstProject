package com.movie.manager;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class MovieDataManager {
    public static List<MovieDTO> movieAllData()
    {
    	List<MovieDTO> list=
    			new ArrayList<MovieDTO>();
    	try
    	{
    		Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/").get();
    		//System.out.println(doc);
    		Elements titleElem=doc.select("div.box-contents strong.title");
    		Elements percentElem=doc.select("div.box-contents strong.percent");
    		Elements imgElem=doc.select("div.box-image span.thumb-image img");
    		/*
    		 *  <span class="like"> 
                            <button class="btn-like" value="78746">��ȭ ���ϱ�</button>
                            <span class="count"> 
                                <strong><i>12,196</i><span>���� ����</span></strong> 
                                <i class="corner-RT"></i><i class="corner-LT"></i><i class="corner-LB"></i><i class="corner-RB"></i><i class="corner-arrow"></i>
                            </span>
                            <a class="link-reservation" href="/ticket/?MOVIE_CD=20009280&MOVIE_CD_GROUP=20009280">����</a>
                        </span>
                        
                        
                         <div class="egg-gage small">
                                <span class="egg great"></span>
								<span class="percent">96%</span>
							</div>


    		 */
    		Elements likeElem=doc.select("div.box-contents span.like span.count strong i");
    		Elements rElem=doc.select("div.box-contents span.txt-info strong");
    		Elements sElem=doc.select("div.box-contents span.percent");
    		for(int i=0;i<titleElem.size();i++)
    		{
    			Element telem=titleElem.get(i);
    			Element pelem=percentElem.get(i);
    			Element ielem=imgElem.get(i);
    			Element lelem=likeElem.get(i);
    			String img=ielem.attr("src");
    			Element relem=rElem.get(i);
    			Element selem=sElem.get(i);
    			MovieDTO d=new MovieDTO();
    			d.setNo(i+1);
    			d.setTitle(telem.text());
    			d.setImage(img);
    			int like=Integer.parseInt(lelem.text().replace(",",""));
    			d.setLike(like);
    			d.setRegdate(relem.text().substring(0, relem.text().indexOf("����")).trim());
    			//System.out.println(telem.text()+" "+pelem.text()+" "+img+" "+lelem.text()+" "+relem.text()+" "+selem.text());
    		    d.setPercent(pelem.text().substring(3, pelem.text().indexOf('%')));
    		    d.setReserve(Double.parseDouble(selem.text().substring(0, selem.text().indexOf('%'))));
    		    list.add(d);
    		}
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    	return list;
    }
	public List<MovieDTO> movieHot()
	{
		List<MovieDTO> list=new ArrayList<MovieDTO>();
		List<MovieDTO> temp=movieAllData();
		int[] rand=new int[2];
		for(int i=0;i<2;i++)
		{
			rand[i]=(int)(Math.random()*(temp.size()));
			MovieDTO d=temp.get(rand[i]);
			list.add(d);
		}
		
		return list;
	}
	public List<String> movie_reserve()
	{
		List<String> list=new ArrayList<String>();
		try
		{
			Document doc=Jsoup.connect("http://movie.naver.com/movie/sdb/rank/rreserve.nhn").get();
			Elements elems=doc.select("td.title div.tit4");
			for(int i=0;i<elems.size();i++)
			{
				Element td=elems.get(i);
				list.add(td.text());
			}
		}catch(Exception ex){}
		return list;
	}
	public List<String> movie_boxoffice()
	{
		List<String> list=new ArrayList<String>();
		try
		{
			Document doc=Jsoup.connect("http://movie.naver.com/movie/sdb/rank/rboxoffice.nhn").get();
			Elements elems=doc.select("td.title div.tit1");
			for(int i=0;i<elems.size();i++)
			{
				Element td=elems.get(i);
				list.add(td.text());
			}
		}catch(Exception ex){}
		return list;
	}

}





