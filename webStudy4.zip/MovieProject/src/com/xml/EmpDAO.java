package com.xml;

public class EmpDAO {

}
