package com.xml;

public class EmpDTO {

}
