package com.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BoardDAO;

public class DeleteOkModel implements Model{

	@Override
	public String handlerRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		String pwd=req.getParameter("pwd");
	     String no=req.getParameter("no");
	     String strPage=req.getParameter("page");
	     // DB���� 
	     BoardDAO dao=new BoardDAO();
	     boolean bCheck=dao.boardDelete(Integer.parseInt(no), pwd);
		 req.setAttribute("bCheck", bCheck);
		 req.setAttribute("page", strPage);
	     return "board/delete_ok.jsp";
	}

}
