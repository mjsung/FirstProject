package com.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.text.SimpleDateFormat;
import java.util.*;
import com.dao.*;
public class ListModel implements Model {

	@Override
	public String handlerRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		 BoardDAO dao=new BoardDAO();
	     String strPage=req.getParameter("page");
	     if(strPage==null)
	    	 strPage="1"; // list.jsp 
	     int curpage=Integer.parseInt(strPage);
	     List<BoardDTO> list=dao.boardListData(curpage);
	     int totalpage=dao.boardTotal();
	     int count=dao.boardCount();
	     count=count-((curpage*10)-10);
	     String msg="�����ڰ� ������ �Խù��Դϴ�";
	     String today=new SimpleDateFormat("yyyy-MM-dd").format(new Date());
	     // ���� ������
	     int block=5;
	     int fromPage=((curpage-1)/block*block)+1;
	     // [1][2][3][4][5] 
	     // fp           tp
	     int toPage=((curpage-1)/block*block)+block;
	     if(toPage>totalpage)
	    	 toPage=totalpage;
	     
	     req.setAttribute("list", list);
	     req.setAttribute("curpage", curpage);
	     req.setAttribute("totalpage", totalpage);
	     req.setAttribute("count", count);
	     req.setAttribute("msg", msg);
	     req.setAttribute("today", today);
	     req.setAttribute("block", block);
	     req.setAttribute("fromPage", fromPage);
	     req.setAttribute("toPage", toPage);
		return "board/list.jsp";
	}

}





