package com.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BoardDAO;
import com.dao.BoardDTO;

public class ReplyOkModel implements Model {

	@Override
	public String handlerRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("EUC-KR");
	    String no=req.getParameter("no");
	    String strPage=req.getParameter("page");
	    String name=req.getParameter("name");
	    String subject=req.getParameter("subject");
	    String content=req.getParameter("content");
	    String pwd=req.getParameter("pwd");
	    // DAO => ���� (����Ŭ�� ������ ����)
	    // ��Ƽ� ���� (DTO)
	    BoardDTO d=new BoardDTO();
	    d.setName(name);
	    d.setSubject(subject);
	    d.setContent(content);
	    d.setPwd(pwd);
	    BoardDAO dao=new BoardDAO();
	    dao.boardReply(Integer.parseInt(no),d);
		return "list.do";
	}

}
