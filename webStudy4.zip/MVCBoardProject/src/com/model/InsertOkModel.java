package com.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BoardDAO;
import com.dao.BoardDTO;

public class InsertOkModel implements Model {

	@Override
	public String handlerRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		// TODO Auto-generated method stub
		// ������ (insert.jsp) �ޱ�
	    req.setCharacterEncoding("EUC-KR");
	    String name=req.getParameter("name");
	    String subject=req.getParameter("subject");
	    String content=req.getParameter("content");
	    String pwd=req.getParameter("pwd");
	    // DAO => ���� (����Ŭ�� ������ ����)
	    // ��Ƽ� ���� (DTO)
	    BoardDTO d=new BoardDTO();
	    d.setName(name);
	    d.setSubject(subject);
	    d.setContent(content);
	    d.setPwd(pwd);
	    BoardDAO dao=new BoardDAO();
	    dao.boardInsert(d);
		return "list.do";
	}

}
