package com.sist.pagecentric.model;
import java.util.List;
import com.sist.pagecentric.dto.CustUserDto;

public interface ICustUserManager {
	public List<CustUserDto> getCustUserList();	
	public CustUserDto getCustUser(String id) ;
	public int addCustUser(CustUserDto uDto);
	public int updateCustUser(CustUserDto uDto);
}
