package com.sist.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;
/*
 *   <bean id="dao" class="com.sist.dao.EmpDAO"
     p:sqlSessionTemplate-ref="sqlTemplete"
    />
 */
@Repository
public class EmpDAO extends SqlSessionDaoSupport{
	@Autowired
	public void initDao(SqlSessionTemplate st)
	{
		setSqlSessionTemplate(st);
	}
    public List<EmpVO> empAllData()
    {
    	 return getSqlSession().selectList("empAlldata");
    }
}
