package com.sist.dao;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.stereotype.Component;
@Component("ds")
/*
 *  <bean id="ds" class="org.apache.commons.dbcp.BasicDataSource"
      p:driverClassName="oracle.jdbc.driver.OracleDriver"
      p:url="jdbc:oracle:thin:@211.238.142.20:1521:ORCL"
      p:username="scott"
      p:password="tiger"
    />
 */
public class MyBasicDataSource extends BasicDataSource{
   public MyBasicDataSource()
   {
	   setDriverClassName("oracle.jdbc.driver.OracleDriver");
	   setUrl("jdbc:oracle:thin:@211.238.142.20:1521:ORCL");
	   setUsername("scott");
	   setPassword("tiger");
   }
}
