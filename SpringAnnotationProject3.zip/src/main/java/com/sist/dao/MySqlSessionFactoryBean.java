package com.sist.dao;

import javax.sql.DataSource;


import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
/*
 *   <bean id="ssf" class="org.mybatis.spring.SqlSessionFactoryBean"
      p:dataSource-ref="ds"
      p:configLocation="Config.xml"
    />
     * 
     *
    class A
    {
      @Autowired
      B b;
      @Autowired
      public A(B b)
      {
      }
      @Autowired
      public void setB(B b)
      {
      }
      @Autowired
      public void initDao(B b)
      {
      }
    }
 */
import java.io.*;
@Component("ssf")
public class MySqlSessionFactoryBean extends SqlSessionFactoryBean{
    @Autowired
	public void initDao(DataSource ds)
    {
    	setDataSource(ds);
    }
    public MySqlSessionFactoryBean()
    {
    	try
    	{
    		Resource res=new ClassPathResource("Config.xml");
    		setConfigLocation(res);
    	}catch(Exception ex){}
    }
}









