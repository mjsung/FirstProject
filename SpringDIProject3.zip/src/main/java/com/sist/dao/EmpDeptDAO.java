package com.sist.dao;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
/*
 *    ResultSet rs=ps.executeQuery();
 *    while(rs.next())
 *    {
 *        EmpDeptSalVO vo=mapRow(rs,10);
 *        list.add(vo)_;
 *    }
 *    
 *    Object mapRow(ResultSet rs, int count)
 *    {
 *    }
 */
public class EmpDeptDAO extends JdbcDaoSupport{
   public List<EmpDeptSalVO> getAllData()
   {
	   String sql="SELECT * FROM empdeptsal_view";
	   return getJdbcTemplate().query(sql, new RowMapper(){

		@Override
		public Object mapRow(ResultSet rs, int count) throws SQLException {
			 EmpDeptSalVO vo=new EmpDeptSalVO();
			   vo.setEmpno(rs.getInt(1));
			   vo.setEname(rs.getString(2));
			   vo.setJob(rs.getString(3));
			   vo.setHiredate(rs.getDate(4));
			   vo.setSal(rs.getInt(5));
			   vo.setDeptno(rs.getInt(6));
			   vo.setDname(rs.getString(7));
			   vo.setLoc(rs.getString(8));
			   vo.setGrade(rs.getInt(9));
			return vo;
		}
		   
	   });
   }
}





