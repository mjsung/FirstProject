package com.sist.orm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 *   �޸� �Ҵ� 
 *   @Component => MovieManager
 *   @Controller => Model
 *   @Repository => DAO
 *   @Service => DAO�������� ��� ��� 
 */
import java.util.*;
import com.sist.dao.*;
@Controller
public class EmpController {
	@Autowired
    private EmpService service;
	@RequestMapping("emp/list.do")
	public String emp_list(String page,Model model)
	{
		if(page==null)
			page="1";
		int curpage=Integer.parseInt(page);
		int rowSize=10;
		int start=(rowSize*curpage)-(rowSize-1);
		int end=(rowSize*curpage);
		Map map=new HashMap();
		map.put("start", start);
		map.put("end", end);
		List<EmpVO> list=service.empAllData(map);
		int totalpage=service.empTotalPage();
		model.addAttribute("curpage", curpage);
		model.addAttribute("totalpage", totalpage);
		model.addAttribute("list", list);
		return "emp/list"; // forward
		// return "redirect:/emp/list.do" sendRedirect()
	}
	@RequestMapping("emp/find.do")
	public String emp_find(String fs,String ss,Model model)
	{
		Map map=new HashMap();
		map.put("fs", fs); // ${}
		map.put("ss", ss.toUpperCase()); // #{}
		List<EmpVO> list=service.empFindData(map);
		model.addAttribute("list", list);
		return "emp/find";
	}
}










