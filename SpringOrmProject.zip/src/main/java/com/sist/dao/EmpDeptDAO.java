package com.sist.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import java.util.*;

import javax.annotation.Resource;
/*
 *    interface I
 *    class A implements I
 *    class B implements I
 *    
 *    <bean id="a" class="A"/>
 *    <bean id="b" class="B"/>
 *    
 *    @Autowired  ==> a,b
 *    @Qualifier("a")
 *    I i
 *    @Resource(name="a")
 *    I i
 */
@Repository
public class EmpDeptDAO extends SqlSessionDaoSupport{
   /*@Autowired
   @Qualifier("sqlSessionTemplate")*/
   @Resource(name="sqlSessionTemplate")
   public void initDao(SqlSessionTemplate st)
   {
	   setSqlSessionTemplate(st);
   }
   public List<EmpVO> empAllData(Map map)
   {
	   return getSqlSession().selectList("empAllData",map);
   }
   public List<EmpVO> empFindData(Map map)
   {
	   return getSqlSession().selectList("empFindData",map);
   }
   public EmpVO empDetailData(int empno)
   {
	   return getSqlSession().selectOne("empDetailData", empno);
   }
   public int empTotalPage()
   {
	   return getSqlSession().selectOne("empTotalPage");
   }
}






