package com.sist.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmpServiceImpl implements EmpService{
    @Autowired
	private EmpDeptDAO dao;
    
	@Override
	public List<EmpVO> empAllData(Map map) {
		// TODO Auto-generated method stub
		return dao.empAllData(map);
	}

	@Override
	public List<EmpVO> empFindData(Map map) {
		// TODO Auto-generated method stub
		return dao.empFindData(map);
	}

	@Override
	public EmpVO empDetailData(int empno) {
		// TODO Auto-generated method stub
		return dao.empDetailData(empno);
	}

	@Override
	public int empTotalPage() {
		// TODO Auto-generated method stub
		return dao.empTotalPage();
	}

}
