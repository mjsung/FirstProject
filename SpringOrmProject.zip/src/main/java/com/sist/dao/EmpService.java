package com.sist.dao;

import java.util.List;
import java.util.Map;

public interface EmpService {
	public List<EmpVO> empAllData(Map map);
	public List<EmpVO> empFindData(Map map);
	public EmpVO empDetailData(int empno);
	public int empTotalPage();
}
