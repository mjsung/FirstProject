package com.sist.join;
import java.util.*;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.*;
public class EmpJoinDAO {
   private static SqlSessionFactory ssf;
   static
   {
	   try
	   {
		   Reader reader=Resources.getResourceAsReader("Config.xml");
		   ssf=new SqlSessionFactoryBuilder().build(reader);
		   // id , sql
	   }catch(Exception ex)
	   {
		   System.out.println(ex.getMessage());
	   }
   }
   public static List<EmpVO> empdeptJoinAllData()
   {
	   SqlSession session=ssf.openSession();
	   List<EmpVO> list=session.selectList("empdeptJoinAllData");
	   session.close();//��ȯ
	   return list;
   }
   public static EmpVO empdeptFindData(int empno)
   {
	   SqlSession session=ssf.openSession();
	   EmpVO vo=session.selectOne("empdeptFindData",empno);
	   session.close();//��ȯ
	   return vo;
   }
}










