package com.sist.pagecentric;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import com.sist.pagecentric.dto.CustUserDto;
import com.sist.pagecentric.model.CustUserService;

public class CustUserListControl extends HttpServlet {
	private static final long serialVersionUID = -5569879474458053375L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}
	
	public void doProcess(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		String scmd = req.getParameter("command");
		if(scmd != null && scmd.equals("list")){
			CustUserService manager=CustUserService.getInstance();
			List<CustUserDto> custs = manager.getCustUserList();
			req.setAttribute("custs", custs);
			dispatch("./custuserlist.jsp", req, resp);
		}else{
			CustError errors = new CustError();
			errors.setErrorMessage("custuserlist 찾을 수가 없습니다");
			errors.setErrorType("custuserlist null 에러");
			req.setAttribute("errors", errors);
			dispatch("./custerror.jsp", req, resp);
		}		
	}
	
	public void dispatch(String urls,HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		RequestDispatcher dispatch = req.getRequestDispatcher(urls);
		dispatch.forward(req, resp);
	}
	
}












