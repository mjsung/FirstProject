package com.sist.pagecentric.model;

import java.util.List;
import com.sist.pagecentric.dto.CustUserDto;

public class CustUserService {
	
	private static CustUserService custUserService= null;
	private ICustUserManager manager = null;
	
	private CustUserService(){
		manager = new CustUserManager();
	}
	public static CustUserService getInstance(){
		if(custUserService == null){
			custUserService = new CustUserService();
		}
		return custUserService;
	}
	
	public List<CustUserDto> getCustUserList(){
		return manager.getCustUserList();
	}
	public int addCustUser(CustUserDto uDto){
		return manager.addCustUser(uDto);
	}
	public CustUserDto getCustUser(String id){
		return manager.getCustUser(id);
	}
	public int updateCustUser(CustUserDto uDto) {
		return manager.updateCustUser(uDto);
	}
	
	public int deleteCustUser(String id){
		return manager.deleteCustUser(id);
	}
	
	public boolean deleteCustUsers(String[] ids){
		return manager.deleteCustUsers(ids);
	}
	
	
}








