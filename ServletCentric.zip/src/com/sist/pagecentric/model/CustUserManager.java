package com.sist.pagecentric.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.sist.pagecentric.dto.CustUserDto;

public class CustUserManager implements ICustUserManager{
	
	private boolean isS = true;
		
	public CustUserManager(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			log("1/6 S");
		}catch(ClassNotFoundException e){
			log("1/6 F", e);
		}
	}	
	public Connection getConnection()throws SQLException{
		Connection conn = null;
		
		String url = "jdbc:oracle:thin:@211.238.142.20:1521:ORCL";
		String user = "scott";
		String passwd = "tiger";
		
		conn = DriverManager.getConnection(url, user, passwd);
		return conn;
	}
	public void close(Connection conn, Statement psmt, ResultSet rs){
		if(rs != null){
			try{
				rs.close();
			}catch(SQLException e){}
		}
		if(psmt != null){
			try{
				psmt.close();
			}catch(SQLException e){}
		}
		if(conn != null){
			try{
				conn.close();
			}catch(SQLException e){}
		}
	}
	
	
	
	@Override
	public List<CustUserDto> getCustUserList() {
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String strQuery = " SELECT ID, NAME, ADDRESS FROM CUSTUSER "
						+ " ORDER BY ID DESC ";
		
		List<CustUserDto> list = new ArrayList<CustUserDto>();
		
		try{
			conn = getConnection();
			psmt = conn.prepareStatement(strQuery);
			System.out.println("strQuery=" + strQuery);
			rs = psmt.executeQuery();
			
			while(rs.next()){
				CustUserDto cust = new CustUserDto();
				cust.setId(rs.getString("id"));
				cust.setName(rs.getString("name"));
				cust.setAddress(rs.getString("address"));
				list.add(cust);
			}			
		}catch(SQLException e){
			System.out.println("Exception " + e);
		}finally{
			this.close(conn, psmt, rs);
		}
		return list;
	}	
	
	@Override
	public int addCustUser(CustUserDto uDto) {
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String strQuery = " INSERT INTO CUSTUSER VALUES(?, ?, ?) ";
		int count = 0;

		try{
			conn = getConnection();
			psmt = conn.prepareStatement(strQuery);
			System.out.println("strQuery=" + strQuery);
			log("1/6 addCustUser");
			
			psmt.setString(1, uDto.getId());
			psmt.setString(2, uDto.getName());
			psmt.setString(3, uDto.getAddress());
			log("2/6 addCustUserS");
			count = psmt.executeUpdate();
			
			log("3/6 addCustUser");
		}catch(SQLException e){			
			System.out.println("Exception " + e);
		}finally{
			this.close(conn, psmt, rs);
		}
		return count;
	}
	
	public CustUserDto getCustUser(String id){
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String strQuery = " SELECT ID, NAME, ADDRESS FROM CUSTUSER "
						+ " WHERE ID=? ";
		
		CustUserDto cust = new CustUserDto();
		try{
			conn = getConnection();
			psmt = conn.prepareStatement(strQuery);
			psmt.setString(1, id.trim());
			System.out.println("strQuery=" + strQuery);
			rs = psmt.executeQuery();
			while(rs.next()){
				cust.setId(rs.getString("id"));
				cust.setName(rs.getString("name"));
				cust.setAddress(rs.getString("address"));
			}			
			System.out.println("getCustUser s");
		}catch(SQLException e){
			System.out.println("Exception " + e);
		}finally{
			this.close(conn, psmt, rs);
		}
		
		return cust;		
	}
	
	public int updateCustUser(CustUserDto uDto){
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String strQuery = " UPDATE CUSTUSER SET NAME=?, ADDRESS=? "
						+ " WHERE ID=? ";
		int count = 0;
		
		try{
			conn=getConnection();
			psmt=conn.prepareStatement(strQuery);
			log("updateCustUser s 1");
			
			psmt.setString(1, uDto.getName());
			psmt.setString(2, uDto.getAddress());
			psmt.setString(3, uDto.getId());
			log("updateCustUser s 2");
			
			count = psmt.executeUpdate();
			log("updateCustUser s 3");
		}catch(SQLException e){
			System.out.println("Exception " + e);
		}finally{
			this.close(conn, psmt, rs);
		}
		return count;
	}
	
	public int deleteCustUser(String id){
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		int count = 0;
		String strQuery = " DELETE FROM CUSTUSER WHERE ID=? ";
		try{
			conn=getConnection();
			log("deleteCustUser s 1");
			psmt=conn.prepareStatement(strQuery);
			psmt.setString(1, id.trim());
			count=psmt.executeUpdate();
			log("deleteCustUser s 2");
		}catch(SQLException e){
			System.out.println("Exception " + e);
		}finally{
			this.close(conn, psmt, rs);
		}
		return count;
	}	
	
	@Override
	public boolean deleteCustUsers(String[] ids) {
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		int[] count = new int[ids.length];
		String strQuery = " DELETE FROM CUSTUSER WHERE ID=? ";
		
		try{
			conn=getConnection();			
			log("deleteCustUsers s 1");
			conn.setAutoCommit(false);
			psmt=conn.prepareStatement(strQuery);
			
			for(int i = 0;i < ids.length; i++){
				psmt.setString(1, ids[i].trim());
				psmt.addBatch();
			}
			count=psmt.executeBatch();
			conn.commit();			
			log("deleteCustUsers s 2");
		}catch(SQLException e){
			try{
				conn.rollback();
			}catch(SQLException e1){}
			System.out.println("Exception " + e);
		}finally{
			try{
				conn.setAutoCommit(true);
			}catch(SQLException e){}
				this.close(conn, psmt, rs);
		}
		
		boolean isS = true;
		
		for(int i = 0;i < count.length; i++){
			if(count[i] != -2){
				isS=false;
				break;
			}
		}	
		
		return isS;
	}
	
	
	
	
	
	public void log(String msg){
		if(isS){
			System.out.println(getClass()+": "+msg);
		}
	}
	public void log(String msg, Exception e){
		if(isS){
			System.out.println(e + ": " + getClass()+": "+msg);
		}
	}
}



