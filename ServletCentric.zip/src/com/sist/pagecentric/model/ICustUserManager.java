package com.sist.pagecentric.model;

import java.util.List;
import com.sist.pagecentric.dto.CustUserDto;

public interface ICustUserManager {
	public List<CustUserDto> getCustUserList();
	public int addCustUser(CustUserDto uDto);
	public CustUserDto getCustUser(String id);
	public int updateCustUser(CustUserDto uDto);
	public int deleteCustUser(String id);
	public boolean deleteCustUsers(String[] ids);
	
}
