package com.sist.pagecentric;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sist.pagecentric.dto.CustUserDto;
import com.sist.pagecentric.model.CustUserService;

public class CustUserAddControl extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}
	
	public void doProcess(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		String scmd = req.getParameter("command");
		if(scmd != null && scmd.equals("add")){
			CustUserService manager = CustUserService.getInstance();
			
			String id = req.getParameter("id");
			String name = req.getParameter("name");
			String address = req.getParameter("address");
			
			if(isNull(id)||isNull(name)||isNull(address)){
				CustError errors = new CustError();
				errors.setErrorMessage("공백이거나 잘못된 문자형식입니다");
				errors.setErrorType("요청 데이터");
				req.setAttribute("errors", errors);
				dispatch("./custerror.jsp", req, resp);
			}else{
				int count = manager.addCustUser(new CustUserDto(id, name, address));
				if(count > 0){
					CustUserDto cust = manager.getCustUser(id);
					req.setAttribute("cust", cust);
					dispatch("./custuserdetail.jsp", req, resp);					
				}else{
					CustError errors = new CustError();
					errors.setErrorMessage("입력에 실패하였습니다");
					errors.setErrorType("DB 작업");
					req.setAttribute("errors", errors);
					dispatch("./custerror.jsp", req, resp);					
				}
			}
		}
		else{
			CustError errors = new CustError();
			errors.setErrorMessage("잘못된 경로로 요청을 하였습니다");
			errors.setErrorType("요청 파라메터");
			req.setAttribute("errors", errors);
			dispatch("./custerror.jsp", req, resp);			
		}
	}
	
	private boolean isNull(String str){
		return str==null || str.trim().equals("");
	}
	
	public void dispatch(String urls,HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		RequestDispatcher dispatch = req.getRequestDispatcher(urls);
		dispatch.forward(req, resp);
	}
}






