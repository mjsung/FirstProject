package com.sist.pagecentric;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sist.pagecentric.dto.CustUserDto;
import com.sist.pagecentric.model.CustUserService;

public class CustMulDeleteControl extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}
	
	public void doProcess(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{

		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");		
		CustUserService manager = CustUserService.getInstance();
		
		String[] ids=req.getParameterValues("delck");
		if(ids==null||ids.length==0){
			CustError errors = new CustError();
			errors.setErrorMessage("id를 한개이상 선택하셔야 합니다");
			errors.setErrorType("요청 파라메터");
			req.setAttribute("errors", errors);
			dispatch("./custerror.jsp", req, resp);	
		}		
		else{
			boolean isS = manager.deleteCustUsers(ids);
			if(!isS){
				CustError errors = new CustError();
				errors.setErrorMessage("삭제에 실패하였습니다");
				errors.setErrorType("DB 작업");
				req.setAttribute("errors", errors);
				dispatch("./custerror.jsp", req, resp);		
			}
			List<CustUserDto> custs = manager.getCustUserList();
			req.setAttribute("custs", custs);
			dispatch("./custuserlist.jsp", req, resp);
		}			
	}
	
	public void dispatch(String urls,HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
		RequestDispatcher dispatch = req.getRequestDispatcher(urls);
		dispatch.forward(req, resp);
	}
}
