package com.sist.dao;

public class AcinfoDTO {
	private int ac_no;
	private String ac_name;
	private String ac_address;
	private String ac_class;
	public int getAc_no() {
		return ac_no;
	}
	public void setAc_no(int ac_no) {
		this.ac_no = ac_no;
	}
	public String getAc_name() {
		return ac_name;
	}
	public void setAc_name(String ac_name) {
		this.ac_name = ac_name;
	}
	public String getAc_address() {
		return ac_address;
	}
	public void setAc_address(String ac_address) {
		this.ac_address = ac_address;
	}
	public String getAc_class() {
		return ac_class;
	}
	public void setAc_class(String ac_class) {
		this.ac_class = ac_class;
	}
	
}
