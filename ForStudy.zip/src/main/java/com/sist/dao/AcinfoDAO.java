package com.sist.dao;

import java.sql.*;
import java.util.*;

public class AcinfoDAO {
   private Connection conn;
   private PreparedStatement ps;
   private final String URL = "jdbc:oracle:thin:@211.238.142.40:1521:ORCL";
   private static AcinfoDAO dao;

   public AcinfoDAO(){
      try{
         Class.forName("oracle.jdbc.driver.OracleDriver");
      }catch(Exception ex){
         System.out.println("AcinfoDAO() 생성자 에러 : "+ex.getMessage());
      }
   }

   public void getConnection(){
      try{
         conn = DriverManager.getConnection(URL, "scott", "tiger");
      }catch(Exception ex){
         System.out.println("getConntection() 에러 : "+ex.getMessage());
      }
   }

   public void disConnection(){
      try{
         if(ps != null) ps.close();
         if(conn != null) conn.close();
      }catch(Exception ex){
         System.out.println("disConnection() 에러 : "+ex.getMessage());
      }
   }

   public static AcinfoDAO newInstance(){
      if(dao == null)
         dao = new AcinfoDAO();
      return dao;
   }

   public List<AcinfoDTO> allData(){
      List<AcinfoDTO> list = new ArrayList<AcinfoDTO>();
      try {
         getConnection();
         String sql = "SELECT ac_no "
         				  + ",ac_name "
         				  + ",ac_address"
         				  + ",ac_class"
         				  + " FROM ac_info "
         				  + " WHERE ROWNUM<20";
         ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery();
         while(rs.next()){
            AcinfoDTO d = new AcinfoDTO();
            d.setAc_address(rs.getString(3));
            list.add(d);
         }
         rs.close();
      }catch(Exception ex){
         System.out.println("allData() 에러 : " + ex.getMessage());
      }finally{
         disConnection();
      }
      return list;
   }
}