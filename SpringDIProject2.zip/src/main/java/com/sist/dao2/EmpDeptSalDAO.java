package com.sist.dao2;
import java.util.*;
import java.sql.*;
public class EmpDeptSalDAO {
    private Connection conn;
    private PreparedStatement ps;
    private String url;
    private String username;
    private String password;
    
    public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public EmpDeptSalDAO(String driver)
    {
		   try
		   {
			   Class.forName(driver); // ���÷��� (Ŭ���� ���� �б�)
			   // �޼ҵ�,�������,�Ű����� 
		   }catch(Exception ex)
		   {
			   System.out.println(ex.getMessage());
		   }
    }
	public void getConnection()
	   {
		   try
		   {
			   conn=DriverManager.getConnection(url,username,password);
		   }catch(Exception ex)
		   {
			   System.out.println(ex.getMessage());
		   }
	   }
	   public void disConnection()
	   {
		   try
		   {
			   if(ps!=null) ps.close();
			   if(conn!=null) conn.close();
		   }catch(Exception ex){}
	   }
	   public List<EmpDeptSalVO> getAllData()
	   {
		   List<EmpDeptSalVO> list=new ArrayList<EmpDeptSalVO>();
		   try
		   {
			   getConnection();
			   String sql="SELECT * FROM empdeptsal_view";
			   ps=conn.prepareStatement(sql);
			   ResultSet rs=ps.executeQuery();
			   while(rs.next())
			   {
				   EmpDeptSalVO vo=new EmpDeptSalVO();
				   vo.setEmpno(rs.getInt(1));
				   vo.setEname(rs.getString(2));
				   vo.setJob(rs.getString(3));
				   vo.setHiredate(rs.getDate(4));
				   vo.setSal(rs.getInt(5));
				   vo.setDeptno(rs.getInt(6));
				   vo.setDname(rs.getString(7));
				   vo.setLoc(rs.getString(8));
				   vo.setGrade(rs.getInt(9));
				   list.add(vo);
			   }
		   }catch(Exception ex)
		   {
			   System.out.println(ex.getMessage());
		   }
		   finally
		   {
			   disConnection();
		   }
		   return list;
	   }
    
}




