package com.sist.di;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sist.dao2.*;
public class MainClass3 {
    private EmpDeptSalDAO mdao;
    
	public void setMdao(EmpDeptSalDAO mdao) {
		this.mdao = mdao;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=
	        	new ClassPathXmlApplicationContext("app.xml");
	        // ClassPath => src/main/java
		    MainClass3 mc=(MainClass3)app.getBean("mc");
	        List<EmpDeptSalVO> list=mc.mdao.getAllData();
	        for(EmpDeptSalVO vo:list)
	        {
	        	System.out.println(vo.getEmpno()+" "
	        			+vo.getEname()+" "
	        			+vo.getJob()+" "
	        			+vo.getSal()+" "
	        			+vo.getDname()+" "
	        			+vo.getLoc()+" "
	        			+vo.getGrade());
	        }
	}

}
