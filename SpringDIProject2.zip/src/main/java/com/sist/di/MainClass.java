package com.sist.di;
import java.util.*;
import com.sist.dao.*;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        EmpDeptSalDAO dao=new EmpDeptSalDAO();
        List<EmpDeptSalVO> list=dao.getAllData();
        for(EmpDeptSalVO vo:list)
        {
        	System.out.println(vo.getEmpno()+" "
        			+vo.getEname()+" "
        			+vo.getJob()+" "
        			+vo.getSal()+" "
        			+vo.getDname()+" "
        			+vo.getLoc()+" "
        			+vo.getGrade());
        }
	}

}










