package com.sist.dao;
import java.util.*;
import java.sql.*;
/*
 *   XML
 *   Annotation ==> DI ( DL(Ŭ���� ã��) , DI(����,�Ű������� ����,�޼ҵ� ȣ��) )
 *                       ==
 *                       lookup()
 */
public class EmpDeptSalDAO {
   private Connection conn;
   private PreparedStatement ps;
   // Statement , PreparedStatement (�⺻), CallableStatement(Procedure)
   private final String DRIVER="oracle.jdbc.driver.OracleDriver";
   private final String URL="jdbc:oracle:thin:@211.238.142.20:1521:ORCL";
   public EmpDeptSalDAO()
   {
	   try
	   {
		   Class.forName(DRIVER); // ���÷��� (Ŭ���� ���� �б�)
		   // �޼ҵ�,�������,�Ű����� 
	   }catch(Exception ex)
	   {
		   System.out.println(ex.getMessage());
	   }
   }
   public void getConnection()
   {
	   try
	   {
		   conn=DriverManager.getConnection(URL,"scott","tiger");
	   }catch(Exception ex)
	   {
		   System.out.println(ex.getMessage());
	   }
   }
   public void disConnection()
   {
	   try
	   {
		   if(ps!=null) ps.close();
		   if(conn!=null) conn.close();
	   }catch(Exception ex){}
   }
   public List<EmpDeptSalVO> getAllData()
   {
	   List<EmpDeptSalVO> list=new ArrayList<EmpDeptSalVO>();
	   try
	   {
		   getConnection();
		   String sql="SELECT * FROM empdeptsal_view";
		   ps=conn.prepareStatement(sql);
		   ResultSet rs=ps.executeQuery();
		   while(rs.next())
		   {
			   EmpDeptSalVO vo=new EmpDeptSalVO();
			   vo.setEmpno(rs.getInt(1));
			   vo.setEname(rs.getString(2));
			   vo.setJob(rs.getString(3));
			   vo.setHiredate(rs.getDate(4));
			   vo.setSal(rs.getInt(5));
			   vo.setDeptno(rs.getInt(6));
			   vo.setDname(rs.getString(7));
			   vo.setLoc(rs.getString(8));
			   vo.setGrade(rs.getInt(9));
			   list.add(vo);
		   }
	   }catch(Exception ex)
	   {
		   System.out.println(ex.getMessage());
	   }
	   finally
	   {
		   disConnection();
	   }
	   return list;
   }
}









