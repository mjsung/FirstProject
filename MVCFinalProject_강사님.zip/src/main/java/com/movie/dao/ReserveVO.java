package com.movie.dao;
/*
 *  
NO
ID
TITLE
THEATER
DAY
INWON
PRICE
RESERVE_CHECK

 */
public class ReserveVO {
    private int no;
    private String id;
    private String title;
    private String theater;
    private String day;
    private int inwon;
    private int price;
    private int reserve_check;
    private String time;
    
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public int getInwon() {
		return inwon;
	}
	public void setInwon(int inwon) {
		this.inwon = inwon;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getReserve_check() {
		return reserve_check;
	}
	public void setReserve_check(int reserve_check) {
		this.reserve_check = reserve_check;
	}
	   
}






