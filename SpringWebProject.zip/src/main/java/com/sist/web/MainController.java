package com.sist.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.dao.MemberVO;

@Controller
public class MainController {
   @RequestMapping("main/input.do")
   public String main_input()
   {
	   return "input";
   }
   @RequestMapping("main/output.do")
   public String main_output(MemberVO vo,Model model)
   throws Exception
   {
	  /* req.setCharacterEncoding("EUC-KR");
	   req.setAttribute("name", req.getParameter("name"));*/
	   model.addAttribute("vo", vo);// ���� 
	   /*
	    *   public void addAttribute(String key,Object obj)
	    *   {
	    *      request.setAttribute(key,obj);
	    *   } 
	    */
	   return "output";
	   /*
	    *   ViewResolver
	    *   public String jspFind(String jsp)
	    *   {
	    *      return prefix+jsp+suffix;
	    *             "/main/"+jsp+".jsp"
	    *   }
	    *   public String 
	    */
   }
}








