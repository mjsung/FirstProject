package com.sist.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller("mc")
public class MainController {
   @RequestMapping("board/main.do")
   @ResponseBody
   public String main_page(@RequestParam HttpServletRequest req)
   {
	   //req.setAttribute("vo", vo);
	   String str="<a href=\"join.do\">�̵�</a>";
	   return str;
   }
   @RequestMapping("board/join.do")
   @Transactional
   public String join_page(HttpServletRequest req)
   {
	   req.setAttribute("msg", "Join_Page");
	   return "join";
   }
}
