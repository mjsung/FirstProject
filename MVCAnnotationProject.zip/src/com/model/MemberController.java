package com.model;

import javax.servlet.http.HttpServletRequest;

import com.controller.Controller;
import com.controller.RequestMapping;

@Controller("memberModel")
public class MemberController {
   @RequestMapping("join.do")
   public String join(HttpServletRequest req)
   {
	   req.setAttribute("msg", "Join_Page");
	   return "view/join.jsp";
   }
}
