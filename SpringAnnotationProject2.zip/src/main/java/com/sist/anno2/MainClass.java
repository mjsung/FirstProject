package com.sist.anno2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.sist.dao.EmpDAO;
import com.sist.dao.EmpVO;

import java.util.*;
@Component("mc")
public class MainClass {
	@Autowired
    private EmpDAO edao;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ApplicationContext app=
        		new ClassPathXmlApplicationContext("app.xml");
        MainClass mc=(MainClass)app.getBean("mc");
        List<EmpVO> list=mc.edao.empAllData();
        for(EmpVO vo:list)
        {
        	System.out.println(vo.getEname()+" "
        			+vo.getHiredate()+" "
        			+vo.getJob());
        }
	}

}






