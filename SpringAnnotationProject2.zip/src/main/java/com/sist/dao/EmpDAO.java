package com.sist.dao;

import javax.inject.Qualifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.*;
/*
 *   �޸� �Ҵ� (Ŭ���� �޸�)
 *   @Component : �Ϲ� Ŭ����
 *   @Repository : DAO(�����)
 *   @Controller : Model
 *   @Service : BO
 *   @Bean
 *   ============== ��ü �޸��Ҵ� 
 *   DI���� (����)
 *   @Autowired : �ڵ� ����
 *   interface I 
 *   class A implements I
 *   class B implements I
 *   <bean id="a" class="A"/>
 *   <bean id="b" class="B"/>
 *   
 *   @Component("a")
 *   class A implements I
 *   @Component("b")
 *   class B implements I
 *   
 *   @Component
 *   class C
 *   {
 *      @Autowired
 *      @Qualifier("a")
 *      
 *      @Resource(name="a")
 *      I i;
 *   }
 *   
 *   @Qualifier : Ư�� ��ü�� ã�Ƽ� ���� 
 *   @Resource => @Autowired + @Qualifier 
 *   ==============
 *   ���� 
 *   1) �޼ҵ�  : @RequestMapping
 *   2) �Ű����� : @RequestParam , @ModelAttribute
 *   ==============
 *   AOP 
 *    @Before
 *    @After
 *    @After-Returning
 *    @After-Throwing
 *    @Arroud
 *    
 */
@Repository
public class EmpDAO {
   @Autowired
   private EmpMapper mapper;
   public List<EmpVO> empAllData()
   {
	   return mapper.empAllData();
   }
   public EmpVO empFindData(int empno)
   {
	   return mapper.empFindData(empno);
   }
   
}











