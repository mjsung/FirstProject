package com.sist.dao;

import org.apache.ibatis.annotations.Select;
import java.util.*;
public interface EmpMapper {
  @Select("SELECT empno,ename,job,hiredate,sal,"
		  +"deptno FROM emp")
  public List<EmpVO> empAllData();
  @Select("SELECT empno,ename,job,hiredate,sal,"
		  +"deptno FROM emp "
		  +"WHERE empno=#{empno}")
  public EmpVO empFindData(int empno);
}
