package com.sist.emp;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// a.jsp ==> a_jsp.java : tomcat(jsp Engine/Webcontainer)

import java.util.*;
import com.sist.dao.*;
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      response.setContentType("text/html;charset=EUC-KR");
	      PrintWriter out = response.getWriter();
	      // OutputStream out = s.getOutputStream();
	      // /EmpServerlet?page=1
	      String strPage = request.getParameter("page");
	      if(strPage ==null)
	      {
	    	  strPage = "1";
	      }
	      int curpage = Integer.parseInt(strPage);
	      EmpDAO dao = new EmpDAO();
	      
	      ArrayList<EmpDTO> list = dao.empAllData(curpage);
	      
	      int totalpage = dao.empTotalPage();
	      
	      out.println("<html>");
	      out.println("<head>");
	      out.println("<style type=text/css>");
	      out.println("th,td{font-family:���� ����;font-size:9pt}");
	      out.println("a{text-decoration:none; color:black}");
	      out.println("a:hover{text-decoration:underline; color:red}");
	      out.println("</style>");
	      out.println("</head>");
	      out.println("<body>");
	      out.println("<center>");
	      out.println("<h3>������</h3>");
	      out.println("<table border=0 width=600>");
	      out.println("<tr bgcolor=#ccccff>");
	      out.println("<th>���</th>");  // tabelheader
	      out.println("<th>�̸�</th>");
	      out.println("<th>����</th>");
	      out.println("<th>�μ�</th>");
	      out.println("<th>�ٹ���</th>");
	      out.println("<th>���</th>");
	      out.println("</tr>");
	      String color = "";
	      int i =0;
	      for(EmpDTO d:list)
	      {
	    	  if(i%2==0)
	    		  color ="white";
	    	  else
	    		  color ="#ccffcc";
	    	  out.println("<tr bgcolor="+color+">");
	    	  out.println("<td>"+d.getEmpno()+"</td>");
	    	  out.println("<td>");
	    	  out.println("<a href=EmpDetailServlet?empno="+d.getEmpno()+">");
	    	  out.println(d.getEname()+"</a>");
	    	  out.println("</td>");
	    	  out.println("<td>"+d.getJob()+"</td>");
	    	  out.println("<td>"+d.getDdto().getDname()+"</td>");
	    	  out.println("<td>"+d.getDdto().getLoc()+"</td>");
	    	  out.println("<td>"+d.getSdto().getGrade()+"</td>");
	    	  out.println("</tr>");
	    	  i++;
	      }
	      out.println("</table>");
	      out.println("<hr width=600>"); //horizontal line
	      out.println("<table border=0 width=600>");
	      out.println("<tr>");
	      out.println("<td align=left>");
	      out.println("Search:");
	      out.println("<select>");
	      out.println("<option>�̸�</option>");
	      out.println("<option>�μ�</option>");
	      out.println("<option>����</option>");
	      out.println("</select>");
	      out.println("<input type=text size=10>");
	      out.println("<input type=button value=ã��>");
	      out.println("</td>");
	      out.println("<td align=right>");
	      out.println("<a href=EmpServlet?page="+(curpage>1?curpage-1:curpage)+">");
	      out.println("<img src=image/pre.gif border=0></a>");
	      /*
	       *    1) 404 : ������ �������� ������ (���ϸ� ã��)
	       *    2) 500 : �ҽ� ������ �󿡼� ���� (�ҽ��ڵ�)
	       *    3) 412 : �ѱ� ��ȯ �ڵ�(EUC-KR, UTF-8)
	       */
	      for(int j=1; j<=totalpage;j++)
	      {
	    	  out.println("[");
	    	  out.println("<a href=EmpServlet?page="+j+">");
	    	  out.println(j);
	    	  out.println("</a>");
	    	  out.println("]");
	      }
	      out.println("<a href=EmpServlet?page="+(curpage<totalpage?curpage+1:curpage)+">");
	      out.println("<img src=image/next.gif border=0></a>");
	      out.println("&nbsp;&nbsp;");
	      out.println(curpage+" page / "+totalpage+" pages");
	      out.println("</td>");
	      out.println("</tr>");
	      out.println("</table>");
	      out.println("</center>");
	      out.println("</body>");
	      out.println("</html>");
	}

}
