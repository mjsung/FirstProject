package com.sist.dao;
/*
 *    grade NUMBER 
 *    losal NUMBER
 *    hisal NUMBER
 */
public class SalGradeDTO {

	private int grade;
	private int losal;
	private int hisal;
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getLosal() {
		return losal;
	}
	public void setLosal(int losal) {
		this.losal = losal;
	}
	public int getHisal() {
		return hisal;
	}
	public void setHisal(int hisal) {
		this.hisal = hisal;
	}
	
}
