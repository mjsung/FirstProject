package com.sist.test;

public interface MyInterface {
   public void display();
}
