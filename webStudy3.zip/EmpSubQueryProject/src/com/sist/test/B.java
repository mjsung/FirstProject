package com.sist.test;

public class B implements MyInterface{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("B:display() Call...");
	}

}

