package com.sist.test;

public class C implements MyInterface{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("C:display() Call...");
	}

}
