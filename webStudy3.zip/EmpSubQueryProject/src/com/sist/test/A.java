package com.sist.test;

public class A implements MyInterface{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("A:display() Call...");
	}

}
