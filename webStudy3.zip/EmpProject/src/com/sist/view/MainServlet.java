package com.sist.view;

import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ���� ��� ���� (������) => html,xml
		// MainServlet?type=1
		response.setContentType("text/html;charset=EUC-KR");
		String type=request.getParameter("type");
		String file="";
		if(type==null)
			type="0";
		switch(Integer.parseInt(type))
		{
		  case 0:
			  file="EmpListServlet";
			  break;
		  case 1:
			  file="InsertServlet";
			  break;
		  case 2:
			  file="EmpDetailServlet";
			  break;
		  case 3:
			  file="EmpUpdateServlet";
			  break;
		}
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<center>");
		// ������ ��� 
		out.println("<table border=1 bordercolor=black width=1000 height=700 cellspacing=0>");
		out.println("<tr>");
		out.println("<td height=150 colspan=2>");
		RequestDispatcher rd=request.getRequestDispatcher("HeaderServlet");
		rd.include(request, response);
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td height=450 width=200>");
		out.println("&nbsp;");
		out.println("</td>");
		out.println("<td height=450 width=800 align=center style=\"margin-top:10px\">");
		
		rd=request.getRequestDispatcher(file);
		rd.include(request, response);
		// <jsp:include>
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td height=100 colspan=2 align=center>");
		out.println("<address>����� ������ ����� ��ȭ���� 2�� A������</address>");
		out.println("</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</center>");
		out.println("</body>");
		out.println("</html>");
		
	}

}







