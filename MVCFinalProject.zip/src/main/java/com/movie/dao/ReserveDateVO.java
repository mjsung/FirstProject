package com.movie.dao;

public class ReserveDateVO {
    private int no;
    private String timeno;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTimeno() {
		return timeno;
	}
	public void setTimeno(String timeno) {
		this.timeno = timeno;
	}
   
}
