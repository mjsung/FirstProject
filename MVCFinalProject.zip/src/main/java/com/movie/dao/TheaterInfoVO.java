package com.movie.dao;
/*
 *  tno NUMBER,
    timeno VARCHAR2(100),
    theater VARCHAR2(30),
    loc VARCHAR2(30)
 */
public class TheaterInfoVO {
    private int tno;
    private String timeno;
    private String theater;
    private String loc;
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public String getTimeno() {
		return timeno;
	}
	public void setTimeno(String timeno) {
		this.timeno = timeno;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	   
}
