create table CUSTUSER(
ID varchar2(50) primary key,
NAME varchar2(50) not null,
ADDRESS varchar2(200) not null
);
