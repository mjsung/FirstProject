package com.sist.di3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sist.dao.*;
public class MainClass {
	
    private myMemberDAO mdao;
    
	public void setMdao(myMemberDAO mdao) {
		this.mdao = mdao;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ApplicationContext app=
        	new ClassPathXmlApplicationContext("app.xml");
        MainClass mc=(MainClass)app.getBean("mc");
       /* MainClass mc=(MainClass)app.getBean("mc");
        MyMemberVO vo=mc.mdao.memberFindData(1);
        System.out.println("�̸�:"+vo.getName());
        System.out.println("����:"+vo.getSex());
        System.out.println("�ּ�:"+vo.getAddr());
        System.out.println("��ȭ:"+vo.getTel());*/
        // ����
       /* MyMemberVO vo=new MyMemberVO();
        vo.setNo(1);
        vo.setName("��û��");
        vo.setSex("����");
        vo.setAddr("���");
        vo.setTel("2222-2222");
        mc.mdao.memberUpdate(vo);*/
        
        MyMemberVO vo=new MyMemberVO();
        /*vo.setName("ȫ�浿");
        vo.setSex("����");
        vo.setAddr("�λ�");
        vo.setTel("3333-3333");
        mc.mdao.memberInsert(vo);*/
        
       /* vo=mc.mdao.memberFindData(2);
        System.out.println("�̸�:"+vo.getName());
        System.out.println("����:"+vo.getSex());
        System.out.println("�ּ�:"+vo.getAddr());
        System.out.println("��ȭ:"+vo.getTel());*/
        // �߰�
        // ����
        mc.mdao.memberDelete(1);
	}

}






