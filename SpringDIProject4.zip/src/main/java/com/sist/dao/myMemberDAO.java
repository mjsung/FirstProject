package com.sist.dao;
import java.util.*;

import oracle.jdbc.OracleTypes;

import java.sql.*;

public class myMemberDAO {
    private Connection conn;
    private CallableStatement cs;
    private String url;
    private String pwd;
    private String user;
	public void setUrl(String url) {
		this.url = url;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public void setUser(String user) {
		this.user = user;
	}
    public myMemberDAO(String driver)
    {
    	try
    	{
    		Class.forName(driver);
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    }
    public void getConnection()
    {
    	try
    	{
    		conn=DriverManager.getConnection(url,user,pwd);
    	}catch(Exception ex){}
    }
    public void disConnection()
    {
    	try
    	{
    		if(cs!=null) cs.close();
    		if(conn!=null) conn.close();
    	}catch(Exception ex){}
    }
    public MyMemberVO memberFindData(int no)
    {
    	MyMemberVO vo=new MyMemberVO();
    	try
    	{
    		getConnection();
    		String sql="{ CALL memberFindData(?,?,?,?,?)}";
    		cs=conn.prepareCall(sql);
    		cs.setInt(1, no);
    		cs.registerOutParameter(2, OracleTypes.VARCHAR);
    		cs.registerOutParameter(3, OracleTypes.VARCHAR);
    		cs.registerOutParameter(4, OracleTypes.VARCHAR);
    		cs.registerOutParameter(5, OracleTypes.VARCHAR);
    		cs.executeUpdate();
    		vo.setNo(no);
    		vo.setName(cs.getString(2));
    		vo.setSex(cs.getString(3));
    		vo.setAddr(cs.getString(4));
    		vo.setTel(cs.getString(5));
    		
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    	finally
    	{
    		disConnection();
    	}
    	return vo;
    }
    public void memberUpdate(MyMemberVO vo)
    {
    	try
    	{
    		getConnection();
    		String sql="{CALL memberUpdate(?,?,?,?,?)}";
    		cs=conn.prepareCall(sql);
    		cs.setInt(1, vo.getNo());
    		cs.setString(2, vo.getName());
    		cs.setString(3, vo.getSex());
    		cs.setString(4, vo.getAddr());
    		cs.setString(5, vo.getTel());
    		
    		cs.executeUpdate();
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    	finally
    	{
    		disConnection();
    	}
    }
    public void memberInsert(MyMemberVO vo)
    {
    	try
    	{
    		getConnection();
    		String sql="{CALL memberInsert(?,?,?,?)}";
    		cs=conn.prepareCall(sql);
    		cs.setString(1, vo.getName());
    		cs.setString(2, vo.getSex());
    		cs.setString(3, vo.getAddr());
    		cs.setString(4, vo.getTel());
    		
    		cs.executeUpdate();
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    	finally
    	{
    		disConnection();
    	}
    }
    public void memberDelete(int no)
    {
    	try
    	{
    		getConnection();
    		String sql="{CALL memberDelete(?)}";
    		cs=conn.prepareCall(sql);
    		cs.setInt(1,no);
    		
    		cs.executeUpdate();
    	}catch(Exception ex)
    	{
    		System.out.println(ex.getMessage());
    	}
    	finally
    	{
    		disConnection();
    	}
    }
}









