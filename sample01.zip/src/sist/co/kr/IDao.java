package sist.co.kr;

import java.util.List;

public interface IDao {	
	boolean addMember(Member dto);
	Member login(Member dto);
	
	boolean writeBBS(BBS bbs);
	List<BBS> getBBSList();

	BBS getBBS(int seq);
	void readCount(int seq);
	boolean answer(int seq, BBS bbs);
	
	boolean addCalendar(myCalendar cal);
	List<myCalendar> getCalendarList(String id, String yyyyMM);
	
	myCalendar getDay(int seq);
	List<myCalendar> getDayList(String id, String yyyymmdd);
	
	public boolean deleteCalendar(int seq);
	

}


















