package sist.co.kr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// Data Access Object
public class MemberDao implements IDao {
	
	private static MemberDao memberDao;
	private boolean isS = true;
	
	private MemberDao(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			log("1/6 S");
		}catch(ClassNotFoundException e){
			log("1/6 F", e);
		}
	}
	
	public static MemberDao getInstance(){
		if(memberDao==null){
			memberDao = new MemberDao();
		}
		return memberDao;
	}
	
	public Connection getConnection()throws SQLException{
		Connection conn = null;
		
		String url = "jdbc:oracle:thin:@211.238.142.20:1521:ORCL";
		String user = "scott";
		String passwd = "tiger";
		
		conn = DriverManager.getConnection(url, user, passwd);
		return conn;
	}
	
	public void close(Connection conn, Statement psmt, ResultSet rs){
		if(rs != null){
			try{
				rs.close();
			}catch(SQLException e){}
		}
		if(psmt != null){
			try{
				psmt.close();
			}catch(SQLException e){}
		}
		if(conn != null){
			try{
				conn.close();
			}catch(SQLException e){}
		}
	}
	
	@Override
	public boolean addMember(Member dto) {
		
		String sql = "INSERT INTO SISTMEMBER "
				+ " (ID, NAME, PWD, EMAIL, AUTH) "
				+ " VALUES(?, ?, ?, ?, 3) ";
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		int count=0;
		
		try{		
			conn = getConnection();
			log("2/6 addMember S");
			
			psmt=conn.prepareStatement(sql);
			int i = 1;
			psmt.setString(i++, dto.getId());
			psmt.setString(i++, dto.getName());
			psmt.setString(i++, dto.getPwd());
			psmt.setString(i++, dto.getEmail());
			log("3/6 addMember S");
			
			count = psmt.executeUpdate();
			log("4/6 S");
		}catch(SQLException e){
			log("F addMember", e);
		}finally{
			this.close(conn, psmt, rs);
			log("5/6 addMember S");
		}		
		
		log("6/6 S addMember");
		
		return count>0?true:false;
	}
	
	@Override
	public Member login(Member dto) {
		
		String sql = " SELECT ID, NAME, EMAIL, AUTH FROM SISTMEMBER "
				+ " WHERE ID=? AND PWD=? ";
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		Member mem = null;
		
		try{
			conn = this.getConnection();
			log("2/6 login S");
			
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, dto.getId());
			psmt.setString(2, dto.getPwd());
			log("3/6 login S");
			
			rs = psmt.executeQuery();
			log("4/6 login S");
			
			while(rs.next()){
				int i = 1;
				String id = rs.getString(i++);
				String name = rs.getString(i++);
				String email = rs.getString(i++);
				int auth = rs.getInt(i++);
				mem = new Member(id, name, null, email, auth);
				
				log(mem.toString());
			}
			log("5/6 login S");
			
		}catch(SQLException e){
			log("F login", e);
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 login S");
		}		
		
		return mem;
	}
		
	@Override
	public boolean writeBBS(BBS bbs) {
		
		String sql = " INSERT INTO BBS "
				+ " (SEQ, ID, REF, STEP, DEPTH, TITLE, "
				+ " CONTENT, WDATE, PARENT, DEL, READCOUNT) "
				+ " VALUES(SEQ_BBS.nextval, "
				+ " ?, "
				+ " (SELECT NVL(MAX(REF), 0)+1 FROM BBS), "
				+ " 0, 0, ?, ?, SYSDATE, 0, 0, 0) ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		int count = 0;
		
		try{
			conn = getConnection();
			log("2/6 writeBBS S");
			
			psmt = conn.prepareStatement(sql);
			int i=1;
			psmt.setString(i++, bbs.getId());
			psmt.setString(i++, bbs.getTitle());
			psmt.setString(i++, bbs.getContent());
			log("3/6 writeBBS S");
			
			count = psmt.executeUpdate();
			log("4/6 writeBBS S");
			
		}catch(SQLException e){
			log("writeBBS F", e);
		}finally{
			this.close(conn, psmt, rs);
			log("5/6 writeBBS S");
		}
		
		log("6/6 writeBBS S");
		
		return count>0?true:false;
	}

	@Override
	public List<BBS> getBBSList() {
		
		String sql = " SELECT SEQ,ID,REF,STEP,DEPTH,TITLE, "
				+ " CONTENT, WDATE, PARENT, DEL, READCOUNT "
				+ " FROM BBS "
				+ " ORDER BY REF DESC, STEP ASC ";
		
		List<BBS> bbsList = new ArrayList<BBS>();
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try{
			conn = this.getConnection();
			log("2/6 getBBSList S");
			
			psmt = conn.prepareStatement(sql);
			log("3/6 getBBSList S");
			
			rs = psmt.executeQuery();
			log("4/6 getBBSList S");
			
			while(rs.next()){
				int i = 1;
				BBS bb = new BBS(
						rs.getInt(i++),		// req
						rs.getString(i++),	// ID
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getInt(i++)						
						);
				bbsList.add(bb);
			}
			log("5/6 getBBSList S");			
		}catch(SQLException e){
			log("getBBSList F", e);
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 getBBSList S");
		}		
		
		return bbsList;
	}
	
	
	@Override
	public BBS getBBS(int seq) {
		
		String sql = " SELECT SEQ,ID,REF,STEP,DEPTH,TITLE, "
				+ " CONTENT, WDATE, PARENT, DEL, READCOUNT "
				+ " FROM BBS "
				+ " WHERE SEQ=? ";
				
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		BBS bb = null;
		
		try{
			conn = this.getConnection();
			log("2/6 getBBS S");			
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, seq);
			log("3/6 getBBS S");			
			rs = psmt.executeQuery();
			log("4/6 getBBS S");
			
			while(rs.next()){
				int i = 1;
				bb = new BBS(
						rs.getInt(i++),		// req
						rs.getString(i++),	// ID
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getString(i++),
						rs.getInt(i++),
						rs.getInt(i++),
						rs.getInt(i++)						
						);
			}
			log("5/6 getBBS S");			
		}catch(SQLException e){
			log("getBBS F", e);
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 getBBS S");
		}		
		
		return bb;
	}

	@Override
	public void readCount(int seq) {
		
		String sql = " UPDATE BBS SET "
				+ " READCOUNT = READCOUNT + 1 "
				+ " WHERE SEQ=? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;		
		
		try{
			conn = getConnection();
			log("2/6 readCount S");
			psmt=conn.prepareStatement(sql);
			psmt.setInt(1, seq);
			log("3/6 readCount S");
			psmt.executeUpdate();
			log("4/6 readCount S");			
		}catch(SQLException e){
			log("readCount F", e);
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 readCount S");
		}
	}
	

	@Override
	public boolean answer(int seq, BBS bbs) {
		
		String sql1 = " UPDATE BBS SET "
				+ " STEP=STEP+1 "
				+ " WHERE REF=(SELECT REF FROM BBS WHERE SEQ=? ) "
				+ " AND STEP>(SELECT STEP FROM BBS WHERE SEQ=? ) ";
		
		String sql2 = "INSERT INTO BBS "
				+ " (SEQ, ID, REF, STEP, DEPTH, TITLE, "
				+ " CONTENT, WDATE, PARENT, DEL, READCOUNT) "
				+ " VALUES(SEQ_BBS.nextval, "
				+ " ?, "
				+ " (SELECT REF FROM BBS WHERE SEQ=? ), "
				+ " (SELECT STEP FROM BBS WHERE SEQ=? )+1, "
				+ " (SELECT DEPTH FROM BBS WHERE SEQ=? )+1, "
				+ " ?, ?, SYSDATE, "
				+ " ?, 0, 0)";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		int count = 0;
		
		try{
			// update
			conn=getConnection();
			conn.setAutoCommit(false);
			log("2/6 answer S");
			
			psmt=conn.prepareStatement(sql1);
			int i=1;
			psmt.setInt(i++, seq);
			psmt.setInt(i++, seq);
			log("3/6 answer S");
			
			count=psmt.executeUpdate();
			
			
			// insert
			psmt.clearParameters();
			psmt=conn.prepareStatement(sql2);
			i=1;
			psmt.setString(i++, bbs.getId());
			psmt.setInt(i++, seq);
			psmt.setInt(i++, seq);
			psmt.setInt(i++, seq);
			psmt.setString(i++, bbs.getTitle());
			psmt.setString(i++, bbs.getContent());
			psmt.setInt(i++, seq);
			log("4/6 answer S");
			
			count=psmt.executeUpdate();
			conn.commit();
			log("5/6 answer S");		
			
		}catch(SQLException e){
			log("answer F", e);
			try{
				conn.rollback();				
			}catch(SQLException e1){}
		}finally{
			try{
				conn.setAutoCommit(true);				
			}catch(SQLException e){}
			this.close(conn, psmt, rs);
			log("6/6 answer S");
		}	
		
		return count>0?true:false;
	}
	
	@Override
	public boolean addCalendar(myCalendar cal) {
		String sql=" INSERT INTO CALENDAR( " +
				" SEQ, ID, TITLE, CONTENT, RDATE, WDATE ) " +
				" VALUES(SEQ_CALENDAR.NEXTVAL, " +
				" ?, ?, ?, ?, SYSDATE) ";
		Connection conn = null;
		PreparedStatement psmt = null;
		int count = 0; 
		
		try{
			conn=getConnection();
			log("2/6 addCalendar S");
			
			psmt=conn.prepareStatement(sql);
			int i=1;
			psmt.setString(i++, cal.getId());
			psmt.setString(i++, cal.getTitle());
			psmt.setString(i++, cal.getContent());
			psmt.setString(i++, cal.getRdate());
			log("3/6 addCalendar S");
			
			count = psmt.executeUpdate();
			log("4/6 addCalendar S");
			
		}catch(SQLException e){
			log("addCalendar F", e);
		}finally{
			this.close(conn, psmt, null);
			log("5/6 addCalendar S");		
		}		
		log("6/6 addCalendar S");
		
		return count>0?true:false;
	}

	@Override
	public List<myCalendar> getCalendarList(String id, String yyyyMM) {
		
		List<myCalendar> cdtos = new ArrayList<myCalendar>();
		
		String sql=" SELECT " +
		" SEQ, ID, TITLE, CONTENT, RDATE, WDATE " +
		" FROM( " +
		" SELECT ROW_NUMBER() " +
		" OVER( partition by substr(RDATE, 1, 8) " +
		" ORDER BY RDATE ASC) RN, " +
		" SEQ, ID, TITLE, CONTENT, RDATE, WDATE " +
		" FROM CALENDAR " +
		" WHERE ID=? AND SUBSTR(RDATE, 1, 6)=? " +
		" ) WHERE RN BETWEEN 1 AND 5 ";	
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try{
			conn=getConnection();
			log("2/6 getCalendarList S");
			
			psmt=conn.prepareStatement(sql);
			psmt.setString(1, id.trim());
			psmt.setString(2, yyyyMM.trim());
			log("3/6 getCalendarList S");
			rs=psmt.executeQuery();
			log("4/6 getCalendarList S");
			
			while(rs.next()){
				myCalendar cdto = new myCalendar();
				
				cdto.setSeq(rs.getInt(1));
				cdto.setId(rs.getString(2));
				cdto.setTitle(rs.getString(3));
				cdto.setContent(rs.getString(4));
				cdto.setRdate(rs.getString(5));
				cdto.setWdate(rs.getString(6));
				
				cdtos.add(cdto);
			}
			log("5/6 getCalendarList S");		
		}catch(SQLException e){
			log("getCalendarList F", e);
		}finally{
			close(conn, psmt, rs);
			log("6/6 getCalendarList S");	
		}		
		
		return cdtos;
	}

	@Override
	public myCalendar getDay(int seq) {
		myCalendar cdto = null;
		
		String sql = " select "
			+ " seq, id, title, content, rdate, wdate "
			+ " from calendar "
			+ " where seq = ? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try{
			conn = getConnection();
			log("2/6 S getDay");
			
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, seq);
			log("3/6 S getDay");
			
			rs = psmt.executeQuery();
			log("4/6 S getDay");
			
			while(rs.next()){
				cdto = new myCalendar();
				int j = 1;
				cdto.setSeq(rs.getInt(j++));
				cdto.setId(rs.getString(j++));
				cdto.setTitle(rs.getString(j++));
				cdto.setContent(rs.getString(j++));
				cdto.setRdate(rs.getString(j++));
				cdto.setWdate(rs.getString(j++));
			}
			log("5/6 S getDay");
		}catch(SQLException e){
			log("F getDay");
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 S getDay");
		}
		
		return cdto;
	}

	@Override
	public List<myCalendar> getDayList(String id, String yyyymmdd) {

		List<myCalendar> cdtos = new ArrayList<myCalendar>();
		
		String sql = " select " 
				+ " seq, id, title, content, rdate, wdate "
				+ " from calendar "
				+ " where id = ? and substr(rdate, 1, 8) = ? "
				+ " order by rdate ";
		
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		try{
			conn = getConnection();
			log("2/6 S getDayList");
			
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id.trim());
			psmt.setString(2, yyyymmdd.trim());			
			log("3/6 S getDayList");
			
			rs = psmt.executeQuery();
			log("4/6 S getDayList");
			
			while(rs.next()){
				myCalendar cdto = new myCalendar();
				int j = 1;
				cdto.setSeq(rs.getInt(j++));
				cdto.setId(rs.getString(j++));
				cdto.setTitle(rs.getString(j++));
				cdto.setContent(rs.getString(j++));
				cdto.setRdate(rs.getString(j++));
				cdto.setWdate(rs.getString(j++));
				
				cdtos.add(cdto);
			}
			log("5/6 S getDayList");
		}catch(SQLException e){
			log("F getDayList");
		}finally{
			this.close(conn, psmt, rs);
			log("6/6 S getDayList");
		}
		
		return cdtos;
	}	

	@Override
	public boolean deleteCalendar(int seq) {
		int count = 0;
		
		String sql = " delete from calendar "
				+ " where seq = ? ";
		
		Connection conn = null;
		PreparedStatement psmt = null;	
		
		try{
			conn = getConnection();
			log("2/6 S deleteCalendar");
			
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, seq);
			log("3/6 S deleteCalendar");
			count = psmt.executeUpdate();
			log("4/6 S deleteCalendar");				
		}catch(SQLException e){
			log("F deleteCalendar");
		}finally{
			this.close(conn, psmt, null);
			log("5/6 S deleteCalendar");	
		}	
		
		return count>0?true:false;
	}

	public void log(String msg){
		if(isS){
			System.out.println(getClass()+": "+msg);
		}
	}
	public void log(String msg, Exception e){
		if(isS){
			System.out.println(e + ": " + getClass()+": "+msg);
		}
	}

}





