package sist.co.kr;

import java.io.Serializable;

/*
drop table calendar
cascade constraints;

drop sequence seq_calendar;
 
create table calendar(
seq number(8) primary key,
id varchar2(50) not null,
title varchar2(200) not null,
content varchar2(4000) not null,
rdate varchar2(12) not null,
wdate date not null
);

create sequence seq_calendar
start with 1 increment by 1;

alter table calendar
add constraint fk_calendar_id foreign key(id)
references sistmember(id);

 
 */

public class myCalendar implements Serializable{
	private int seq;
	private String id;
	private String title;
	private String content;
	private String rdate;	// 기록 날짜 레코드 데이트
	private String wdate;
	
	public myCalendar(){}
	
	public myCalendar(int seq, String id, String title, String content, String rdate, String wdate)
	{
		super();
		this.seq = seq;
		this.id = id;
		this.title = title;
		this.content = content;
		this.rdate = rdate;
		this.wdate = wdate;
	}
	
	public myCalendar(String id, String title, String content, String rdate)
	{
		super();		
		this.id = id;
		this.title = title;
		this.content = content;
		this.rdate = rdate;		
	}

	@Override
	public String toString() {
		return "Calendar[seq=" + seq + ", id=" + id + ", title=" + title
				+ ", content=" + content + ", rdate=" + rdate 
				+ ", wdate=" + wdate + "]";
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRdate() {
		return rdate;
	}

	public void setRdate(String rdate) {
		this.rdate = rdate;
	}

	public String getWdate() {
		return wdate;
	}

	public void setWdate(String wdate) {
		this.wdate = wdate;
	}
	

}
